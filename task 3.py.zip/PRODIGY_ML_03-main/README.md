# PRODIGY_ML_03
Implement a Support Vector Machine (SVM) to classify images of cats and dogs from the Kaggle dataset.
Dataset: https://www.kaggle.com/c/dogs-vs-cats/data
